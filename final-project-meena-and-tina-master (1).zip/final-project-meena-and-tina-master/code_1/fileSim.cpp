#include <cstddef>
#include <fstream>
#include <iostream>
#include <sstream>
#include <time.h>
using namespace std;

#include <filesystem>
namespace fs = std::filesystem;

#include "fileSim.hpp"
#include <vector>



// ===========Lifecycle methods===========

FileSim::FileSim(int _diskSize) : numCollisions(0) {
    diskSize = _diskSize;

    root = new Inode;
    root->parentNode = nullptr;
    root->name = "(root)";
    root->creationTime = time(NULL);
    root->modTime = root->creationTime;
    root->isDirectory = true;
    currentDir = root;
    currentUsedDiskMemory = 0;

    // Add Hash Table intialization
    tableSize = 5;
    table = new HashNode*[tableSize];
    for (int i = 0; i < tableSize; ++i) {
        table[i] = nullptr;
    }
}
int recursiveDelete(Inode *node) {
  
    // we can probably call this for the deconstructor.
    // and for the rm function if they want to remove subdirectories.

    vector <Inode*> children = node->childNodes;
    int cSize = children.size();

    int delSize = 0;

    // if a node has no children then it won't go into the loop at all.
    for(int i=0; i<cSize; i++)
    {
        if(children[i]->isDirectory)
        {
            // If it is a directory then call the function again with that node to check and delete it's children.

            delSize += recursiveDelete(children[i]);
        }
        else{
            // update used disk memory:
            delSize += children[i]->fileSize;

            // if it is just a file, then just delete the child and set to null.
            delete children[i];
            //children[i] = nullptr;
            // update used disk memory:
        }
         }
    // update used disk memory:
    //currentUsedDiskMemory -= node->fileSize;
    // once all children are deleted then delete the node and set to null.
    delSize += node->fileSize;
    delete node;
    //node = nullptr;

     return delSize;
}

FileSim::~FileSim() {
    // Any postprocessing that may be required
    recursiveDelete(root);
    // delete hashtable
    if(hashTableType == LINEAR_PROBING)
    {
        for(int i = 0; i < tableSize; i++)
        {
            delete table[i];
        }
    }
    else if(hashTableType == QUADRATIC_PROBING) 
    {
        for(int i = 0; i < tableSize; i++)
        {
            delete table[i];
        }
    }
    else
    {
        HashNode *temp = nullptr;
        HashNode *crawler = nullptr;
        for(int i = 0; i < tableSize; i++)
        {
                crawler = table[i];
                while(crawler != nullptr)
                {
                    temp = crawler->next;
                    delete crawler;
                    crawler = temp;
                }
        }
    }
 
}



// ===========Helper methods===========

int FileSim::makeNode(std::string name, bool isDirectory) {

    if (currentUsedDiskMemory + 1 <= diskSize)
    {
        Inode* newNode = new Inode;
        newNode->name = name;
        newNode->creationTime = time(NULL); // I think this returns current time,
        // so whenever this function is called to make the new node it returns that timestamp.
        newNode->modTime = newNode->creationTime;
	    // as this was just created, the modTime is the same as created time.
        newNode->isDirectory = isDirectory;
        newNode->parentNode = currentDir;
        currentDir->childNodes.push_back(newNode);
        // Made parent the currentDirectory that the user is in.
        // update used disk memory:


        currentUsedDiskMemory += 1;
        // return 1 if new node was added and disk memory did not go over.

        if (!newNode->isDirectory) // If the node created is a file, then insert the node into the Hash Table
        {

            insertItem(name, newNode);
           
            // if(hashTableType == LINEAR_PROBING)
            // {
            //     insertItemLinear(name, newNode); // This inserts based on hashTableType in fileSim.hpp
            // }
            // else if(hashTableType == QUADRATIC_PROBING)
            // {
            //     insertItemQuadratic(name, newNode);
            // }
            // else if(hashTableType == CHAINING)
            // {
            //     insertItemChaining(name, newNode);
            // }

        }
        return 1;
    }
    // return 0 if new node could not be added because no space in disk.
    return 0;
}

Inode* getChild(Inode* parent, std::string name) {
    // iterate over children vector to find the child of parent.
    // Not sure if this needs to include "grandchildren" or just direct children.
    // So this implementation just includes direct children.

    vector <Inode*> children = parent->childNodes;
    int vSize = children.size();

    for(int i = 0; i<vSize; i++)
    {
        if(children[i]->name == name)
        {
            return children[i];
        }
    }

    return nullptr;
}

Inode* FileSim::pathToNode(std::string path) {
    // Returns the node pointed to by `path`.
    //
    // `path` may be...
    //    1. The special path '..', which returns the parent of the current
    //       directory, or the current directory if there is no parent.
    //    2. An absolute path in the format /dir1/dir2/...
    //       where / is the root and /dir1 is a child directory of the root.
    //    3. A relative path (a file in the current working directory)

    // 1
    if (path == "..") {
        return currentDir->parentNode;
    }

    // 2 & 3
    Inode *node;
    if (path.front() == '/') {
        node = root; // 2
        path = path.substr(1);
        
    } else {
        node = currentDir; // 3
    }

    std::stringstream pathStream(path);
    std::string pathSegment;
    std::vector<std::string> seglist;

    while (std::getline(pathStream, pathSegment, '/')) {
        if (Inode* child = getChild(node, pathSegment)) {
            node = child;
        } else {
            return nullptr;
        }
    }
    return node;
}

std::string FileSim::nodeToPath(Inode *node) {
    // Returns an absolute path given a node
    if (!node->parentNode) {
        // Root
        return "/";
    }

    std::string path = "";
    while (node->parentNode) {
        path.insert(0, "/" + node->name);
        node = node->parentNode;
    }
    return path;
}


void treeHelper(Inode* node, int level) {
    // Recursively print the node's contents
    vector <Inode*> children = node->childNodes;
    int cSize = children.size();
    
    // If the first call, print a space.
    if (level == 0)
    {
        cout << " ";
    }
    // Print directory name
    if(node->name == "")
    {
        return;
    }
    cout << node->name << endl;
    //cout << "CSIZE" << cSize << endl;
    for (int i = 0; i<cSize; i++)
    {
        cout << "- " ;
        // This should print the children in order and if a child is a directory itself then it will recursively recall the function 
        // for that directory's children.
        if(children[i]->isDirectory)
        {
            treeHelper(children[i], level+1);
        }

        else
        {
            // print the file name
            cout << children[i]->name << endl;
        }
    }
}

std::string timeToString(time_t t) {
    string time = ctime(&t);
    return time;
}

// ===========Public API===========

int FileSim::touch(std::string fileName) {
    // check if inserting file exceeds disk capacity
    //int size = fileName.size();
    if(currentUsedDiskMemory + 1 > diskSize)
    {
        cout << "No space left on disk!" << endl;
        //cout << "Cannot add file. Inserting a new file will exceed disk capacity." << endl;
        return -1;
    }




    // check if file with fileName already exists
    vector <Inode*> tempChildren = currentDir->childNodes;
    int tempSize = tempChildren.size();
    for(int i = 0; i < tempSize; i++)
    {
        if(tempChildren[i]->name == fileName)
        {
            cout << "Duplicate name: " << fileName << endl;
            //cout << "Cannot add file. A file with this name already exists in this directory." << endl;
            return -1;
        }
    }


    // otherwise, create inode with directory = false
    // ask user to enter file name
    // add filename to hash table
    // set file size to 1
    // update creation time to current time
    // insert node into current directory


    return makeNode(fileName, false);
    //return 0;
}


int FileSim::mkdir(std::string dirName) {
    // check if inserting file exceeds disk capacity
    // int size = fileName.size();
    if(currentUsedDiskMemory + 1 > diskSize)
    {
        cout << "No space left on disk!" << endl;
        //cout << "Cannot add file. Inserting a new file will exceed disk capacity." << endl;
        return -1;
    }




    // check if file with fileName already exists
    vector <Inode*> tempChildren = currentDir->childNodes;
    int tempSize = tempChildren.size();
    for(int i = 0; i < tempSize; i++)
    {
        if(tempChildren[i]->name == dirName)
        {
            cout << "Duplicate name: " << dirName << endl;
            //cout << "Cannot add file. A file with this name already exists in this directory." << endl;
            return -1;
        }
    }


    // otherwise, create inode with directory = false
    // ask user to enter file name
    // add filename to hash table
    // set file size to 1
    // update creation time to current time
    // insert node into current directory


   
    return makeNode(dirName, true);

    // return 0;
}

void FileSim::ls() {


    vector<Inode*> tempChildren = currentDir->childNodes;
    for(int i = 0; i < tempChildren.size(); i++)
    {
        cout << tempChildren[i]->name << endl;
    }
}

void FileSim::pwd() {

    string path = nodeToPath(currentDir);


    if (path == "")
    {
        cout << "File system is empty. No paths available." << endl;
        return;
    }
    cout << path << endl;

    // I don't know if this can error out, unless there are no directories. So I just added this condition.
}

void FileSim::tree() {

    treeHelper(currentDir, 0);
}


int FileSim::cat(std::string path) {
    Inode* givenNode = nullptr;

    vector <Inode*> children = currentDir->childNodes;
    int cSize = children.size();
    for(int i =0; i<cSize; i++)
    {
        if (path == children[i]->name)
        {
            givenNode = children[i];
        }
    }


    if(givenNode != nullptr && !(givenNode->isDirectory))
    {
        cout << givenNode->fileData << endl;

        return 1;
    }


    if(!givenNode)
    {
        // Note we need to get the actual file/directory name enterd even if not in the tree.
        cout << "cat: " << path << ": No such file or directory" << endl;
    }


    else if(givenNode->isDirectory)
    {
        cout << "cat: " << givenNode->name << ": Is a directory" << endl;
    }

  

    return 0;
}

int FileSim::stat(std::string path) {
    Inode* givenNode = pathToNode(path);


    if(givenNode != nullptr && !(givenNode->isDirectory))
    {
        int nameSize = givenNode->name.length();
        int dotIndex = 0;
        for(int i = 0; i < nameSize; i++)
        {
            if (givenNode->name[i] == '.')
            {
                dotIndex = i;            
            }
        }
        cout << "stat: " << givenNode->name << ":" << endl;
        cout << "File Size: " << givenNode->fileSize << endl;
        cout << "File Type: " << givenNode->name.substr(dotIndex) << endl;
        cout << "Creation Time: " << timeToString(givenNode->creationTime);
        cout << "Modified Time: " << timeToString(givenNode->modTime);
        cout << "Parent Directory:" << givenNode->parentNode->name << endl;

        return 1;
    }


    if(!givenNode)
    {
        // Note we need to get the actual file/directory name enterd even if not in the tree.
        cout << "stat: none: No such file or directory" << endl;
    }


    else if(givenNode->isDirectory)
    {
        cout << "stat: " << givenNode->name << ": Is a directory" << endl;
    }
 
    return 0;
}

int FileSim::edit(std::string path, std::string newValue) {
    // Overwrite the file with a new value
    Inode* pathNode = nullptr;
    // check if inode exists in current directory
    vector <Inode*> children = currentDir->childNodes;
    int cSize = children.size();
    for(int i =0; i<cSize; i++)
    {
        if (path == children[i]->name)
        {
            pathNode = children[i];
        }
    }
    if(pathNode == nullptr)
    {
        cout << "edit: " << path << ": No such file or directory" << endl; 
        return 0;
    }
    // if it exists in directory, check that the node is a file type
    if(pathNode->isDirectory == true)
    {
        cout << "edit: " << path << ": Is a directory" << endl;
        return 0;
    }
    // make sure this doesn't go past diskSize capacity 
    int newSize = pathNode->fileSize + newValue.size();
    if(newSize + currentUsedDiskMemory >= diskSize)
    {
        cout << "edit: No more space left on disk" << endl;
        return 0;
    }
    // if all conditions are passed, override filedata with newValue and update filesize
    // I'm not completely sure how to update the node
    // right now, I'm updating the temp node, but I don't think this updates the actual node
    pathNode->fileData = newValue;
    pathNode->fileSize = newSize;
    pathNode->modTime = time(NULL);
    return 1;
}

int FileSim::cd(std::string dirPath) {
    // call pathToNode and set that node to currentDirectory.
    // unless nullptr is returned then that node does not exist.
    Inode* dirNode = nullptr;
    // check if inode exists in current directory
    vector <Inode*> children = currentDir->childNodes;
    int cSize = children.size();
    for(int i =0; i<cSize; i++)
    {
        if (dirPath == children[i]->name)
        {
            dirNode = children[i];
        }
    }

    if (dirPath == "..")
    {
        dirNode = currentDir->parentNode;
    }


    if (dirNode && dirNode->isDirectory)
    {
        currentDir = dirNode;
        return 1;
    }


    if(!dirNode)
    {
        cout << "cd: no such file or directory: " << dirPath << endl;
    }

    else if(!(dirNode->isDirectory))
    {
        cout << "cd: not a directory: " << dirNode->name << endl;
    }

    return 0;
}

int FileSim::rm(std::string path, bool recursive) {


   Inode* pathNode = pathToNode(path);
   int index = 0;


    // check if the node is ..
    if(path == "..")
    {
        cout << "rm: '.' and '..' may not be removed" << endl;
        // if(pathNode->parentNode != nullptr)
        // {
        //     delete pathNode->parentNode;
        //     pathNode->parentNode = nullptr;
        //     return 1;
        // }
        // else
        // {
        //     return 0;
        // }
        return 0;
    }
    // check if node exists
    if(pathNode == nullptr)
    {
        cout  << "rm: " << path << ": No such file or directory" << endl;
        return 0;
    }
     // check if it is in current directory
    bool found = false;
    for(int i = 0; i < currentDir->childNodes.size(); i++)
    {
        if(currentDir->childNodes[i]->name == pathNode->name)
        {
            index = i;
            found = true;
        }
    }
    if(!found)
    {
        //cout << "rm: " << pathNode->name << ": No such file or directory" << endl;
        //cout << "HERE!" << endl;
        return 0;
    }
    // if it's a directory node:
    if(pathNode->isDirectory == true)
    {
        if(recursive == false)
        {
            cout << "rm: " << path << ": is a directory" << endl;
            return 0;

        }
        recursiveDelete(pathNode);
        pathNode->parentNode->childNodes.erase(pathNode->parentNode->childNodes.begin() + index);
        return 1;

    }
    // if its a filetype:
    else
    {
        // Also delete from Hash Table!
        int index = hashFunction(pathNode->name);
        HashNode* getNode = searchItem(pathNode->name); // returns a hash node of first instance
        Inode* givenInode;
        if (hashTableType == CHAINING)
        {
            HashNode* previous = nullptr;
            // If node to delete is head:
            givenInode = getNode->iptr;
            if(pathNode->creationTime == givenInode->creationTime)
            {
		delete pathNode;
                currentDir->childNodes.erase(currentDir->childNodes.begin() + index);
                HashNode* temp = getNode;
                getNode = getNode->next;
                delete temp;
                temp = nullptr;
            }
            else
            {
                while(getNode != nullptr) // For chaining we just keep iterating through next to get all the hash nodes of a given key.
                {
                    givenInode = getNode->iptr;
                    if(pathNode->creationTime == givenInode->creationTime)
                    {
                        delete pathNode;
                        currentDir->childNodes.erase(currentDir->childNodes.begin() + index);
                        previous->next = getNode->next;
                        delete getNode;
                        getNode = nullptr;

                    }
                    previous = getNode;
                    getNode = getNode->next;
                }
                
            }
        }
        else if (hashTableType == LINEAR_PROBING)
        {
            while(index < tableSize)
            {
                if(table[index] != nullptr && table[index]->iptr->creationTime == pathNode->creationTime)
                {
                    delete pathNode;
                    currentDir->childNodes.erase(currentDir->childNodes.begin() + index);
                    delete table[index];
                    table[index] = nullptr;
                    break;
                }
                index ++;
            }
        }
        else if(hashTableType == QUADRATIC_PROBING)
        {
            int i = index;
            int a = 1;
            while(index < tableSize)
            {
                if(table[index] != nullptr && table[index]->iptr->creationTime == pathNode->creationTime)
                {
                    delete pathNode;
                    pathNode->parentNode->childNodes.erase(pathNode->parentNode->childNodes.begin() + index);
                    delete table[index];
                    table[index] = nullptr;
                    break;
                }
                index = i + a^2;
                a++;
            }

        }

        /*delete pathNode;
        //pathNode = nullptr;
        pathNode->parentNode->childNodes.erase(pathNode->parentNode->childNodes.begin() + index);*/
        return 1;
    }

    return 0;
}

int FileSim::mv(std::string originPath, std::string destPath) {
    // get nodes from calling pathToNode function. Get parent of dest and change originPath node's parent to dest parent.
    // either change name of node or change location:
    Inode* pathNode = nullptr;
    vector <Inode*> children = currentDir->childNodes;
    int cSize = children.size();
    for(int i = 0; i<cSize; i++)
    {
        if(children[i]->name == originPath)
        {
            pathNode = children[i];
        }
    }
    Inode* parent = pathToNode(destPath);
     // check if node exists
    if(pathNode == nullptr)
    {
        cout << "mv: " << originPath << ": No such file or directory" << endl;
        return 0;
    }
    if(parent == nullptr)
    {

        // Either the user wants to change a fileName or entered a directory that does not exist.
        bool dir = true;
        int nameSize = destPath.length();
        for(int i = 0; i<nameSize; i++)
        {
            if(destPath[i] == '.')
            {
                dir = false;
            }
        }
        if (!pathNode->isDirectory && !dir) // If it was a file name then reset pathNode->name
        {
            pathNode->name = destPath;
            // Changing the name of the file changes the index that it is stored in the table.
            int index = hashFunction(pathNode->name);
            HashNode* getNode = searchItem(pathNode->name); // returns a hash node of first instance
            Inode* givenInode;
            if (hashTableType == CHAINING)
            {
                HashNode* previous = nullptr;
                // If node to delete is head:
                givenInode = getNode->iptr;
                if(pathNode->creationTime == givenInode->creationTime)
                {
                    HashNode* temp = getNode;
                    getNode = getNode->next;
                    delete temp;
                    temp = nullptr;
                }
                else
                {
                    while(getNode != nullptr) // For chaining we just keep iterating through next to get all the hash nodes of a given key.
                    {
                        givenInode = getNode->iptr;
                        if(pathNode->creationTime == givenInode->creationTime)
                        {
                            previous->next = getNode->next;
                            delete getNode;
                            getNode = nullptr;

                        }
                        previous = getNode;
                        getNode = getNode->next;
                    }
                    
                }
            }
            else if (hashTableType == LINEAR_PROBING)
            {
                while(index < tableSize)
                {
                    if(table[index] != nullptr && table[index]->iptr->creationTime == pathNode->creationTime)
                    {
                        delete table[index];
                        table[index] = nullptr;
                        break;
                    }
                    index ++;
                }
            }
            else if(hashTableType == QUADRATIC_PROBING)
            {
                int i = index;
                int a = 1;
                while(index < tableSize)
                {
                    if(table[index] != nullptr && table[index]->iptr->creationTime == pathNode->creationTime)
                    {
                        delete table[index];
                        table[index] = nullptr;
                        break;
                    }
                    index = i + a^2;
                    a++;
                }
            }
            insertItem(pathNode->name, pathNode);
            return 1;
        //cout << "mv: " << destPath << ": No such file or directory" << endl;
        }
        return 0;
    }
    // check if node we are moving origin node to the same place
    if(pathNode->name == parent->name)
    {
        cout << "mv: " << destPath << ": Already exists!" << endl;
        return 0;
    }
    // change name if filetype
    /*if(pathNode->isDirectory == false)
    {


        pathNode->name = parent->name;
        return 1;
    }*/
    //change location if it is a directory type
    else
    {
        //delete node from childvector of current parent
        int index = 0;
        for(int i = 0; i < pathNode->parentNode->childNodes.size(); i++)
        {
            if(pathNode->parentNode->childNodes[i]->name == pathNode->name)
            {
                index = i;
            }
        }
        pathNode->parentNode->childNodes.erase(pathNode->parentNode->childNodes.begin() + index);
        // reassign parent pointer
        pathNode->parentNode = parent;
        // add node to child vector of new parent
        parent->childNodes.push_back(pathNode);
        return 1;
    }

    return 0;
}

void FileSim::search(std::string key) {
    int index = hashFunction(key);
    HashNode* getNode = searchItem(key); // returns a hash node of first instance
    Inode* givenInode;
    string path = "";
    if (hashTableType == CHAINING)
    {
        while(getNode != nullptr) // For chaining we just keep iterating through next to get all the hash nodes of a given key.
        {
            givenInode = getNode->iptr;
            path = nodeToPath(givenInode);
            cout << path << endl;
            getNode = getNode->next;
        }
    }
    else if (hashTableType == LINEAR_PROBING)
    {
        while(index < tableSize)
        {
            if(table[index] != nullptr && table[index]->key == key)
            {
                givenInode = table[index]->iptr;
                path = nodeToPath(givenInode);
                cout << path << endl;
            }
            index ++;
        }
    }
    else if(hashTableType == QUADRATIC_PROBING)
    {
        int i = index;
        int a = 1;
        while(index < tableSize)
        {
            if(table[index] != nullptr && table[index]->key == key)
            {
                givenInode = table[index]->iptr;
                path = nodeToPath(givenInode);
                cout << path << endl;
            }
            index = i + a^2;
            a++;
        }

    }

}

// ===========Hash Table===========

HashNode *FileSim::createNode(std::string _key, Inode *_iptr, HashNode *_next) {
    HashNode* newNode = new HashNode;

    newNode->key = _key;
    newNode->iptr = _iptr;
    newNode->next = _next;

    return newNode;
}

// Hash Function
unsigned int FileSim::hashFunction(string s) {
    // Division Method
    int sum = 0;
    int stringLength = s.length();
    for (int i=0; i < stringLength; i++)
    {
        sum += s[i];
    }

    return sum%tableSize;
}

// Search Method
HashNode *FileSim::searchItem(string key) {
    int index = hashFunction(key);

    HashNode* getNode = table[index]; // returns first hashNode of given key.

    return getNode;
}

// Insert new record
bool FileSim::insertItemLinear(std::string _key, Inode *_iptr) {

      // Index = hash(record.key)

      // while(table[index] is occupied)
	    // Index ++;
    // Table[index]

    // check if table is full

    if(numElements +1 > tableSize)
    {
        cout << "table is full. Resizing Linear." << endl;
        // cout << "table size: " << tableSize << endl;
        // return 0;
        resizeHashTable();

    }

    int index = hashFunction(_key);

    int store = index;
    bool collisionTrue = 0;

    while(table[index] != nullptr)
    {
        if(collisionTrue == false)
        {
            numCollisions++;
            collisionTrue = true;
        }
        index ++;
        if(index == store)
        {
            cout << "table is full. Resizing Linear." << endl;
            resizeHashTable();
        }
    }
    // if(index >= tableSize )
    // {
    //     cout << "table is full. Resizing Linear." << endl;
    //     resizeHashTable();
    // }

    // add hashnode to table
    // I'm not really sure what the past parameter is supposed to be
    table[index] = createNode( _key,  _iptr, nullptr);
    // update the table size
    numElements ++;


    return true;
}

bool FileSim::insertItemQuadratic(std::string _key, Inode *_iptr) {
    int i = hashFunction(_key);
    int index = i;
    int store = i;


    int a = 1;
    bool collisionTrue = 0;
    while(table[index] != nullptr)
    {
        //numCollisions++;
        if(collisionTrue == false)
        {
            numCollisions++;
            collisionTrue = true;
        }
	    index = i + a^2;
        a++;
        // check if table is full
        if(index == store)
        {
            cout << "table is full. Resizing Quadratic." << endl;
            resizeHashTable();
        }
        // if(index > tableSize +1)
        // {
        //     cout << "table is full. Resizing Quadratic." << endl;
        //     resizeHashTable();
        //     //return 0;
        // }
    }

    // add the hashnode to the table
    // again, not really sure what the last parameter is supposed to be
    // I said it is null because I think the *next pointer isn't pointing to anything right now
    table[index] = createNode( _key,  _iptr, nullptr);
    // update table size
    numElements ++;

    return true;
}

bool FileSim::insertItemChaining(std::string _key, Inode *_iptr) {
    // Note next is the ptr for the next Inode in the LL given a chaining implementation
    int index = hashFunction(_key);
    HashNode* crawler = table[index];
    // return false if hash Table is full.

    if (crawler == nullptr) // make head, add Inode
    {
        table[index] = createNode(_key, _iptr, nullptr);
        numElements++;
        return true;
    }
    // If head is already occupied
    numCollisions++;
    while(crawler != nullptr)
    {
        if(crawler->next == nullptr) // Open space! Add Inode
        {
            numElements++;

            // numCollisions++;

            crawler->next == createNode(_key, _iptr, nullptr);
            break;
        }

        crawler = crawler->next;

    }

    return true;

}


//Resize the table
void FileSim::resizeHashTable() {
    cout << "RESIZING" << endl;
    int oldSize = tableSize;
    tableSize = 2*tableSize;
    HashNode **temp = table;
    table = new HashNode*[tableSize];
    for(int i = 0; i < tableSize; i++)
    {
         table[i] = nullptr;
    }

    for(int j = 0; j < oldSize; j++)
    {
        HashNode* current = temp[j];

        while(current != nullptr)
        {
            insertItem(current->key, current->iptr);
            HashNode* temp2 = current;

            delete temp2;
            temp2 = nullptr;
            current = current->next;

        }
    }
        // if(hashTableType  == LINEAR_PROBING)
        // {
        //     for(int i = 0; i <oldSize; i++)
        //     {

        //         insertItemLinear(table[i]->key, table[i]->iptr);
        //     }
        // }
        // else if(hashTableType == QUADRATIC_PROBING)
        // {
        //     for(int i = 0; i <oldSize; i++)
        //     {
        //         insertItemQuadratic(table[i]->key, table[i]->iptr);
        //     }
        // }
        // else
        // {
        //     cout << "Chaining. Don't need to resize" << endl;
        //     return;
        // }

    // delete [] table;
    // table = temp;
}

void FileSim::resetCollisions() {
    numCollisions = 0;
}

int FileSim::getCollisions() const {
    return numCollisions;
}
