#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include "../code_1/fileSim.cpp"
using namespace std;

void testHashTable(FileSim& fs) {
    fs.resetCollisions();
    std::cout << "Collisions: " << fs.getCollisions() << std::endl;
    for (int i = 0; i < 30; i++) {
        std::string dirName = "dir" + std::to_string(i);
        std::string fileName = "file" + std::to_string(i);

        fs.mkdir(dirName);
        cout << dirName << endl;
        fs.cd(dirName);
        fs.touch(fileName);
        cout << fileName << endl;
        fs.cd("..");
    }
    std::cout << "Collisions: " << fs.getCollisions() << std::endl;
}

int main(){
    cout << "linear probing:" << endl;
    cout << "------------------" << endl; 
    FileSim file1(1000);
    file1.setHashTableType(LINEAR_PROBING);
    testHashTable(file1);

    cout << endl;
    cout << "quadratic probing:" << endl;
    cout << "------------------" << endl; 
    FileSim file2(1000);
    file2.setHashTableType(QUADRATIC_PROBING);
    testHashTable(file2);

    cout << endl;
    cout << "chaining:" << endl;
    cout << "----------------" << endl; 
    FileSim file3(1000);
    file3.setHashTableType(CHAINING);
    testHashTable(file3);


    return 0;
}